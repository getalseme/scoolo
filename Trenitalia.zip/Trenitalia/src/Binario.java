public class Binario {

    private String name;
    public Binario(String name){
        this.name = name;
    }

    @Override
    public String toString(){
        return name;
    }

}
