import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Canvas extends JPanel {

    private String[] stations;

    public Color[] colors = new Color[13];


    public Canvas(String[] stations) {
        super();
        Arrays.fill(this.colors, Color.BLACK);
        this.stations = stations;
    }

    public void paint(Graphics g){
        int i;
        for (i = 0; i < 3; i++) {
            g.setColor(this.colors[(4*i)]);
            g.drawRect(10 + (245*i), 200, 100, 70);
            g.drawString(this.stations[i],10 + (245*i), 190);
            g.setColor(this.colors[1 + (4*i)]);
            g.drawLine(110 + (245*i), 235, 160 + (245*i), 235);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(160 + (245*i), 235, 175 + (245*i), 200);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(160 + (245*i), 235, 175 + (245*i), 270);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(175 + (245*i), 200, 200 + (245*i), 200);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(175 + (245*i), 270, 200 + (245*i), 270);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(200 + (245*i), 200, 215 + (245*i), 235);
            g.setColor(this.colors[2 + (4*i)]);
            g.drawLine(200 + (245*i), 270, 215 + (245*i), 235);
            g.setColor(this.colors[3 + (4*i)]);
            g.drawLine(215 + (245*i), 235, 255 + (245*i), 235);
        }
        g.setColor(this.colors[12]);
        g.drawString(this.stations[i],10 + (245*i), 190);
        g.drawRect(255+ (245*2),200,100,70);
        repaint();
    }
}
