import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        JFrame finestra = new JFrame("Window");
        finestra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        finestra.setSize(1000, 600);
        String [] stations = {"Venezia", "Salzano", "Resana", "Castelfranco"};
        Canvas canvas = new Canvas(stations);
        finestra.setContentPane(canvas);
        finestra.setVisible(true);


        System.out.println("inizio processo principale");
        Linea_Bassano_Venezia l1= new Linea_Bassano_Venezia();
        String[] mioPath1 = {"Salzano","b3","sc2","b4","Resana","b5","sc3","b6","Bassano"};
        String[] mioPath2 = {"Bassano","b6","sc3","b5","Resana","b4","sc2","b3","Salzano"};
        Treno t1 = new Treno("t1", l1, mioPath1, canvas, Color.GREEN);
        Treno t2 = new Treno("t2", l1, mioPath2, canvas, Color.BLUE);
        t1.start();
        t2.start();
    }
}
