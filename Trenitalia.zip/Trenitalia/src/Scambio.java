public class Scambio {

    private String name;
    public Scambio(String name){
        this.name = name;
    }

    @Override
    public String toString(){
        return name;
    }

}
